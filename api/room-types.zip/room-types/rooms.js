// api/rooms.js — the hotel's own rooms, drawn from the hotel's own website (M972; browser fallback M974; puppeteer pairing M976; hosted browser M977; token diagnostics M978; longer answers + salvage M979; numbered images M980; booking link M985; the hotel's own menu first + a real rooms-page test M995; www-blind hostnames + redirect-to-home means no page M996; a hollow page is read again in the browser M997; own /reservations/ booking link M1002; big-group booking links M1011; hollow menu pages opened in the browser before judging M1013; hard 50 s answer + browser budget M1014; the hotel's own pages before the group's M1015; the parent list page first + straight to the browser on a 403 site M1016; SynXis links by signature M1018; the Supabase rooms store M1019; list pages first on a refusing site M1020; the menu's list page before guesses M1021; finishes in the background after answering M1022; reading marker + the rooms stretch of a big page M1023; store trail + background failures noted M1024; one browser session per request M1025; one store key per hotel + trust cutoff M1027, 27 Oct 2026).
//
// M974: plain requests from our server were refused by Four Seasons and the Lotte alike
// ("unreachable") — luxury hotel sites sit behind bot protection that turns away anything that
// is not a real browser. So when the plain request fails, the page is opened in the same
// server-side browser the rates reader uses, which passes those checks and also renders pages
// built in JavaScript. ?debug=1 lists every address tried and what came back.
//
// The client chooses a room ON VOYAGE ONE — names, sizes, beds, occupancy and the hotel's own
// photographs — and never has to visit the hotel's site. This function fetches the hotel's
// accommodation page on our server, reduces it to readable text with its image and link
// addresses, and has the same model that powers Help extract the room list as JSON. One method
// for every brand and every independent: no per-site parser to break when a page is redesigned.
//
// GET /api/rooms?hotel=<name>&site=<hotel website>
// Returns: { ok:true, hotel, source, fetched, rooms:[{ name, category, size, beds, occupancy,
//            view, description, images:[url], url }] }
// Cached at the edge for 30 days (rooms change rarely; a new suite appears within the month).
// Needs ANTHROPIC_API_KEY (already set for help.js). Without it: { ok:false, reason:"no-key" }.
//
// Universal rules: never invent a room; every value comes from the page or is null; images are
// the hotel's own addresses, served from the hotel's server (if a site blocks hot-linking the
// card falls back to its usual photograph).

import chromiumPkg from "@sparticuz/chromium";
import puppeteer from "puppeteer-core";

const MODEL = "claude-haiku-4-5-20251001";
const TRIED = [];
// WHERE THE BROWSER RUNS (M977, 25 Oct 2026). Vercel's function image lacks a system library the
// bundled Chromium needs ("libnss3.so"), so the browser is hosted: with BROWSERLESS_TOKEN set in
// Vercel, the readers connect to Browserless (plumbing, like Vercel or Supabase — nothing a
// client sees); without it they still try the bundled browser, which works on hosts that have
// the library. ?debug=1 reports which one answered.
async function openBrowser() {
  const token = (process.env.BROWSERLESS_TOKEN || "").trim();
  if (token) {
    const region = process.env.BROWSERLESS_REGION || "production-sfo";
    const ws = `wss://${region}.browserless.io?token=${encodeURIComponent(token)}&stealth=true&blockAds=true`;
    const browser = await puppeteer.connect({ browserWSEndpoint: ws, defaultViewport: { width: 1180, height: 1600 } });
    return { browser, via: "browserless" };
  }
  chromiumPkg.setGraphicsMode = false;
  const browser = await puppeteer.launch({ args: chromiumPkg.args, defaultViewport: { width: 1180, height: 1600 }, executablePath: await chromiumPkg.executablePath(), headless: chromiumPkg.headless });
  return { browser, via: "bundled" };
}

// The same page, fetched by a real browser. Used whenever the plain request is refused.
// ONE BROWSER SESSION PER REQUEST (M1025). Each browser read used to connect, open, read and close
// (~8 s of overhead each); a site that refuses plain requests needed three of them and the read
// no longer fit inside one call. The session is opened once and reused; closed at the end.
let SESSION = null;
async function sessionPage() {
  if (SESSION && SESSION.page) return SESSION;
  const opened = await openBrowser();
  const page = await opened.browser.newPage();
  await page.setUserAgent(UA);
  await page.setExtraHTTPHeaders({ "Accept-Language": "en-US,en;q=0.9" });
  SESSION = { browser: opened.browser, page, via: opened.via };
  return SESSION;
}
async function closeSession() { if (SESSION) { try { await SESSION.browser.close(); } catch (e) {} SESSION = null; } }
async function getWithBrowser(url) {
  try {
    const s = await sessionPage();
    const resp = await s.page.goto(url, { waitUntil: "domcontentloaded", timeout: 25000 });
    try { await s.page.waitForNetworkIdle({ idleTime: 600, timeout: 6000 }); } catch (e) {}
    // SCROLL THE PAGE AS A GUEST WOULD (M1043, 2 Nov 2026). Mandarin Oriental's /stay read back
    // 21 rooms with good descriptions and not one photograph: its pictures load only as they come
    // into view, so a page read at the top holds placeholders. Scrolling to the end in screen-sized
    // steps lets every lazy picture load before the page is read. Universal: most hotel sites load
    // photographs this way. Capped at 30 steps and a few seconds.
    try {
      await s.page.evaluate(async () => {
        const step = Math.max(400, window.innerHeight * 0.9);
        for (let i = 0; i < 30; i++) { const before = window.scrollY; window.scrollBy(0, step); await new Promise((r) => setTimeout(r, 180)); if (window.scrollY === before) break; }
        window.scrollTo(0, 0);
      });
      try { await s.page.waitForNetworkIdle({ idleTime: 500, timeout: 4000 }); } catch (e) {}
    } catch (e) {}
    await new Promise((r) => setTimeout(r, 800));
    const html = await s.page.content();
    const finalUrl = s.page.url();
    TRIED.push({ url, via: "browser:" + s.via, status: resp ? resp.status() : null, bytes: html.length });
    return html && html.length > 500 ? { url: finalUrl, html, via: "browser" } : null;
  } catch (e) {
    TRIED.push({ url, via: "browser", hosted: !!(process.env.BROWSERLESS_TOKEN || "").trim(), error: String(e && e.message || e).slice(0, 700) });
    await closeSession();
    return null;
  }
}
const UA = "Mozilla/5.0 (iPad; CPU OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";
const ROOM_PATHS = ["/accommodations", "/rooms-suites", "/rooms-and-suites", "/rooms", "/accommodation", "/stay", "/suites", "/en/rooms", "/en/accommodations", "/villas"];

async function get(url) {
  try {
    const r = await fetch(url, { headers: { "User-Agent": UA, "Accept": "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }, redirect: "follow" });
    const ct = r.headers.get("content-type") || "";
    TRIED.push({ url, via: "fetch", status: r.status, type: ct.slice(0, 40) });
    if (r.ok && /html/i.test(ct)) { const html = await r.text(); if (html.length > 500) return { url: r.url, html, via: "fetch" }; }
    if (r.status === 404) return null;              // a real "no such page": no point opening a browser on it
  } catch (e) { TRIED.push({ url, via: "fetch", error: String(e && e.message || e).slice(0, 120) }); }
  return await getWithBrowser(url);
}
function abs(base, href) { try { return new URL(href, base).toString(); } catch (e) { return null; } }
// HTML → readable text keeping image addresses and links, so the reader can tie photos to rooms.
// Images are numbered as they are kept, so the reader can refer to "image 7" and the server
// restores the exact address — long addresses were being abbreviated when copied (M980).
// GARBLED ACCENTS REPAIRED (3 Nov 2026). Mandarin Oriental Ritz Madrid came back with "CÃ©sar Ritz",
// "dÃ©cor" and "frontâ€‘row": the hotel's UTF-8 text had been read somewhere as Windows-1252. Any
// string that carries those tell-tale pairs is turned back into its bytes and read again as UTF-8;
// if that does not give clean text, the string is left exactly as it was. Universal — every hotel,
// every field, including rooms already in the store.
const CP1252 = { "€": 0x80, "‚": 0x82, "ƒ": 0x83, "„": 0x84, "…": 0x85, "†": 0x86, "‡": 0x87, "ˆ": 0x88, "‰": 0x89, "Š": 0x8a, "‹": 0x8b, "Œ": 0x8c, "Ž": 0x8e, "‘": 0x91, "’": 0x92, "“": 0x93, "”": 0x94, "•": 0x95, "–": 0x96, "—": 0x97, "˜": 0x98, "™": 0x99, "š": 0x9a, "›": 0x9b, "œ": 0x9c, "ž": 0x9e, "Ÿ": 0x9f };
const MOJIBAKE = /[Â-ô][\u0080-¿ŒœŠšŸŽžƒˆ˜–—‘-„†-•…‰‹›€™]/;
function unGarble(v) {
  if (typeof v !== "string" || !MOJIBAKE.test(v)) return v;
  const bytes = [];
  for (const ch of v) {
    const c = ch.codePointAt(0);
    if (c <= 0xff) bytes.push(c); else if (CP1252[ch] != null) bytes.push(CP1252[ch]); else return v;
  }
  try { return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(bytes)); } catch (e) { return v; }
}
// A PHOTO ADDRESS IS A REAL ADDRESS (3 Nov 2026). Mandarin's pages write "&amp;" inside image addresses
// (…cover=624x300&amp;quality=75); passed on as written, every photograph failed to load. Decoded
// here for new reads and for rooms already in the store. Universal.
const cleanUrl = (u) => (typeof u === "string" ? u.replace(/&amp;/gi, "&") : u);
const unGarbleRoom = (r) => (r && typeof r === "object" ? Object.fromEntries(Object.entries(r).map(([k, x]) => [k, k === "images" && Array.isArray(x) ? x.map(cleanUrl) : Array.isArray(x) ? x : k === "url" ? cleanUrl(x) : unGarble(x)])) : r);

// EACH ROOM'S PHOTO FROM ITS OWN PAGE (3 Nov 2026). On a list page the reader can only guess which
// picture sits nearest which name, and it guessed wrong: Mandarin Oriental Ritz Madrid's
// Two-Bedroom Presidential Suite came back with a photograph of a train compartment, and most rooms
// with none. Almost every brand site gives each room its own page, and that page names its own
// photograph for sharing (og:image / twitter:image) — the hotel's own choice of picture for that
// room. Whenever a room has its own page, that photograph replaces the guess. A picture that every
// room page shares is the site's general image, not the room's, and is ignored. A room whose page
// gives no photograph keeps no guessed photograph either: a blank tile is honest, a wrong picture
// is not. Universal — every hotel whose rooms have their own pages. Each room carries
// photoChecked once this has run, so it runs once per stored hotel.
// Every photograph a room page carries, in page order: its sharing photo first (og:image /
// twitter:image), then real <img>/<source> addresses, then picture addresses written inside the
// page's own data (Mandarin Oriental's room pages carry no sharing photo and draw their gallery
// from data embedded in the page — 1.5 MB of it, 3 Nov 2026).
const PIC = /\.(?:jpe?g|webp|png|avif)(?:[?#]|$)|\/is\/image\/|\/images?\/|[?&](?:wid|width|w|cover|quality|fit|crop)=/i;
const NOT_PIC = /\.(?:svg|js|css|json|woff2?|ttf|ico|gif)(?:[?#]|$)|logo|sprite|icon|favicon|placeholder|pixel|tracking|badge|flag|social|share-default|default[-_]?(?:share|og)/i;
function pagePhotos(html, base) {
  const out = []; const seen = new Set();
  const push = (u) => { if (!u) return; u = cleanUrl(String(u).replace(/\\u002F/gi, "/").replace(/\\\//g, "/").trim()); const a = abs(base, u); if (!a || !/^https?:\/\//.test(a) || !PIC.test(a) || NOT_PIC.test(a) || seen.has(a)) return; seen.add(a); out.push(a); };
  const metas = html.match(/<meta\b[^>]*>/gi) || [];
  for (const want of ["og:image:secure_url", "og:image", "twitter:image", "twitter:image:src"]) for (const m of metas) {
    const k = /\b(?:property|name)\s*=\s*["']([^"']+)["']/i.exec(m); const c = /\bcontent\s*=\s*["']([^"']+)["']/i.exec(m);
    if (k && c && k[1].toLowerCase() === want) push(c[1]);
  }
  const tags = html.match(/<(?:img|source)\b[^>]*>/gi) || [];
  for (const t of tags) { const re = /\b(?:data-src|data-lazy-src|data-original|src|data-srcset|srcset)\s*=\s*["']([^"']+)["']/gi; let m; while ((m = re.exec(t))) push(m[1].split(/\s*,\s*/)[0].split(/\s+/)[0]); }
  const re = /https?:(?:\/\/|\\\/\\\/|\\u002F\\u002F)[^"'\s<>()]+/gi; let m;
  while ((m = re.exec(html)) && out.length < 400) push(m[0]);
  return out;
}
const PHOTO_PASS = 2;   // raised whenever the way room photographs are read changes, so stored hotels are read again once
// A ROOM'S OWN PAGE MUST BE ITS OWN (3 Nov 2026). Belmond La Residencia lists room TYPES — Signature
// Suites & Villas, Suites, Junior Suites, Deluxe Rooms — and they can all point to one page, or to
// the list page itself with a #section. Treated as four "own pages", every photo appeared on all of
// them, was judged site furniture, and every photograph was thrown away. A page counts as a room's
// own only when no other room points to it and it is not the list page; any other room keeps the
// photographs it already had. Universal — every hotel that lists room types.
const pageOf = (u) => { try { const x = new URL(u); return (x.hostname.replace(/^www\./, "") + x.pathname.replace(/\/+$/, "")).toLowerCase(); } catch (e) { return ""; } };
function ownPages(rooms, listUrl) {
  const n = {}; rooms.forEach((r) => { const k = r && r.url ? pageOf(r.url) : ""; if (k) n[k] = (n[k] || 0) + 1; });
  const list = listUrl ? pageOf(listUrl) : "";
  return (r) => { const k = r && r.url ? pageOf(r.url) : ""; return !!k && n[k] === 1 && k !== list; };
}
async function roomPagePhotos(rooms, budgetMs, listUrl) {
  const until = Date.now() + budgetMs;
  const own = ownPages(rooms, listUrl);
  const list = rooms.map((r) => ({ r, url: own(r) ? r.url : null, photo: null, ok: false }));
  const plain = async (it) => {
    try {
      const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 9000);
      const r = await fetch(it.url, { headers: { "User-Agent": UA, "Accept": "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9" }, redirect: "follow", signal: ctl.signal });
      clearTimeout(tm);
      TRIED.push({ url: it.url, via: "room-page", status: r.status });
      if (r.ok) { it.ok = true; it.photos = pagePhotos(await r.text(), r.url); } else it.status = r.status;
    } catch (e) { it.error = String(e && e.message || e).slice(0, 80); }
  };
  const todo = list.filter((it) => it.url);
  for (let i = 0; i < todo.length && Date.now() < until - 3000; i += 6) await Promise.all(todo.slice(i, i + 6).map(plain));
  // A site that refuses plain requests: the same pages in the one browser session, while time allows.
  for (const it of todo) {
    if (it.ok || Date.now() > until - 6000) continue;
    try {
      const sess = await sessionPage();
      await sess.page.goto(it.url, { waitUntil: "domcontentloaded", timeout: 12000 });
      it.ok = true; it.photos = pagePhotos(await sess.page.content(), sess.page.url());
      TRIED.push({ url: it.url, via: "room-page:browser" });
    } catch (e) { TRIED.push({ url: it.url, via: "room-page:browser", error: String(e && e.message || e).slice(0, 80) }); }
  }
  // A picture on more than one room's page is the site's own furniture — the header, the
  // "other rooms" carousel, the footer — not this room. A room's photographs are the ones only its
  // own page carries, in the order the page shows them; the first two are kept.
  const counts = {}; list.forEach((it) => (it.photos || []).forEach((u) => { counts[u] = (counts[u] || 0) + 1; }));
  const read = list.filter((it) => it.ok).length;
  return list.map((it) => {
    const r = it.r; if (!r || !it.url) return r;
    if (Date.now() > until && !it.ok && !it.status && !it.error) return r;   // never reached for lack of time: next visit
    if (!it.ok) return { ...r, photoTried: Date.now() };      // page not reached: left as it was, tried again after a day
    const own = (it.photos || []).filter((u) => read < 3 || counts[u] === 1).slice(0, 2);
    return { ...r, images: own, photoChecked: PHOTO_PASS };
  });
}
const IMAGES = [];
function distill(html, base) {
  IMAGES.length = 0;
  let h = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<!--[\s\S]*?-->/g, " ").replace(/<svg[\s\S]*?<\/svg>/gi, " ").replace(/<noscript>/gi, "").replace(/<\/noscript>/gi, "");
  // A PICTURE IS ITS BEST REAL ADDRESS (M1043). Lazy pages put a placeholder in src
  // (data:image/gif…, a 1-pixel blank) and the real photograph in data-src / data-srcset / srcset,
  // or in a <picture>'s <source>. The first REAL address among them is the photograph; a
  // <picture> becomes one image; a CSS background-image on a card counts as an image too.
  const realOf = (tag) => {
    const attrs = []; const re = /\b(data-src|data-lazy-src|data-original|data-lazy|data-srcset|srcset|src)\s*=\s*["']([^"']+)["']/gi; let m;
    while ((m = re.exec(tag))) attrs.push([m[1].toLowerCase(), m[2].trim()]);
    const order = ["data-src", "data-lazy-src", "data-original", "data-lazy", "src", "data-srcset", "srcset"];
    attrs.sort((a, b) => order.indexOf(a[0]) - order.indexOf(b[0]));
    for (const [k, v] of attrs) {
      const u = /srcset$/.test(k) ? v.split(/\s+\d+[wx]\s*,?\s*|,\s+(?=\S+\s+\d+[wx])/)[0].trim().split(/\s+/)[0] : v;
      if (u && !/^data:|^about:|blank\.(gif|png)|placeholder|spacer|1x1/i.test(u)) return u;
    }
    return "";
  };
  h = h.replace(/<picture\b[\s\S]*?<\/picture>/gi, (blk) => {
    const img = /<img\b[^>]*>/i.exec(blk); const fromImg = img ? realOf(img[0]) : "";
    let u = fromImg; if (!u) { const srcs = blk.match(/<source\b[^>]*>/gi) || []; for (const t of srcs) { u = realOf(t); if (u) break; } }
    const alt = img ? /\balt\s*=\s*["']([^"']*)["']/i.exec(img[0]) : null;
    return u ? `<img src="${u.replace(/"/g, "&quot;")}"${alt ? ` alt="${alt[1].replace(/"/g, "&quot;")}"` : ""}>` : " ";
  });
  h = h.replace(/<(div|section|figure|a|span|li)\b([^>]*style\s*=\s*["'][^"']*background(?:-image)?\s*:[^"']*url\(\s*['"]?([^'")]+)['"]?\s*\)[^"']*["'][^>]*)>/gi, (tag, el, rest, u) => `<${el}${rest}><img src="${u}">`);
  h = h.replace(/<img\b[^>]*>/gi, (tag) => {
    // Prefer a plain src; fall back to a srcset. A srcset is a comma-separated LIST, so only
    // there is a comma a separator — an address itself may contain commas (Four Seasons' do).
    const alt = /\balt\s*=\s*["']([^"']*)["']/i.exec(tag);
    let u = realOf(tag);
    if (!u || /^data:/.test(u)) return " ";
    u = abs(base, u.replace(/&amp;/gi, "&")); if (!u) return " ";
    if (/\.svg(\?|$)|\/icons?\/|logo|sprite|pixel|tracking/i.test(u)) return " ";
    IMAGES.push(u);
    return ` [IMG#${IMAGES.length}${alt && alt[1] ? " | " + alt[1].trim() : ""}] `;
  });
  h = h.replace(/<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>/gi, (tag, href) => { const u = abs(base, href); return u ? ` [LINK ${u}] ` : " "; });
  h = h.replace(/<(?:br|\/p|\/div|\/li|\/h[1-6]|\/tr|\/section|\/article)\b[^>]*>/gi, "\n").replace(/<[^>]+>/g, " ");
  h = h.replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&ndash;/g, "–").replace(/&mdash;/g, "—").replace(/&#(\d+);/g, (m, n) => String.fromCharCode(Number(n)));
  return h.replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
}
// Find the accommodation page: known paths first, then any link on the home page that says rooms.
// Does this page actually show rooms? Not "the word room appears" — Rosewood answered a guessed
// address with its HOME page and a 200, and the word appears there too (M995, 25 Oct 2026). A rooms
// page names several rooms or suites and gives sizes or beds; its own canonical address does not
// point somewhere else.
function looksLikeRooms(got, wanted) {
  const html = got.html || "";
  const canon = (/<link[^>]+rel=["']canonical["'][^>]+href=["']([^"']+)["']/i.exec(html) || /<meta[^>]+property=["']og:url["'][^>]+content=["']([^"']+)["']/i.exec(html) || [])[1];
  // Served from somewhere else: the page's canonical address, or the address it redirected to,
  // is the home page or a parent of what we asked for → a missing page dressed as a 200 (M996).
  const norm = (u) => { try { return new URL(u).pathname.replace(/\/+$/, "").toLowerCase() || "/"; } catch (e) { return ""; } };
  if (wanted) {
    const w = norm(wanted);
    for (const actual of [canon, got.url]) {
      if (!actual) continue; const a = norm(actual);
      if (a && w && a !== w && (w.startsWith(a + "/") || a === "/")) return false;
    }
  }
  const text = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ");
  const heads = (html.match(/<h[1-4][^>]*>[\s\S]*?<\/h[1-4]>/gi) || []).map((x) => x.replace(/<[^>]+>/g, " ").trim()).filter((x) => /\b(room|suite|villa|residence|tent|penthouse|apartment|bungalow|cabin|lodge)\b/i.test(x));
  const sizes = (text.match(/\b\d{2,4}\s?(?:m²|m2|sq\.?\s?m|sq\.?\s?ft|square (?:feet|metres|meters))/gi) || []).length;
  const beds = (text.match(/\b(king|queen|twin|double)\s+bed/gi) || []).length;
  // A LIST THAT LINKS TO ITS ROOMS (M1042, 2 Nov 2026). Mandarin Oriental's /stay names its rooms on
  // cards, not in headings, and shows no sizes or beds on the list — so it was judged "not a rooms
  // page" while linking straight to /stay/deluxe-prado-view-room, /stay/junior-suite,
  // /stay/two-bedroom-royal-suite… A page that links to three or more pages BENEATH ITS OWN ADDRESS
  // whose names are rooms or suites is the hotel's rooms list. Universal: any hotel that gives each
  // room its own page under the list (most brand sites do).
  const here = (() => { try { return new URL(got.url || wanted).pathname.replace(/\/+$/, "").toLowerCase(); } catch (e) { return ""; } })();
  const children = new Set();
  if (here && here !== "/") {
    const re = /href\s*=\s*["']([^"'#?]+)/gi; let m;
    while ((m = re.exec(html))) {
      try {
        const p = new URL(m[1].replace(/&amp;/g, "&"), got.url || wanted).pathname.replace(/\/+$/, "").toLowerCase();
        if (p.startsWith(here + "/") && /(^|[-_])(room|rooms|suite|suites|villa|villas|residence|penthouse|apartment|bungalow|cabin|tent)([-_]|$)/.test(p.slice(here.length + 1))) children.add(p);
      } catch (e) {}
    }
  }
  return heads.length >= 3 || (heads.length >= 1 && (sizes >= 2 || beds >= 2)) || sizes >= 4 || children.size >= 3;
}
// Find the accommodation page: THE HOTEL'S OWN MENU FIRST (the link it calls Accommodation, Rooms,
// Suites, Stay, Villas…), then the usual addresses, and only a page that looks like a rooms page.
// The same site with or without "www." — Google often gives the bare host while the hotel's own
// links carry www. (Rosewood, M996). One hostname rule for every hotel.
const host = (u) => { try { return new URL(u).hostname.replace(/^www\./i, "").toLowerCase(); } catch (e) { return ""; } };
const sameSite = (a, b) => host(a) && host(a) === host(b);
async function findRoomsPage(site) {
  const T0 = Date.now(); let browserReads = 0;
  const base = /^https?:\/\//.test(site) ? site : "https://" + site;
  const origin = new URL(base).origin;
  const root = base.replace(/\/+$/, "");
  const tried = new Set();
  // A page the hotel's own menu calls Accommodation/Rooms/Stay that arrives hollow is opened in the
  // browser BEFORE being judged (M1013): script-drawn rooms pages (Mandarin Oriental's /stay) were
  // being rejected as "not a rooms page" on their empty shell.
  const hollow = (got) => { const t = String(got.html || "").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " "); return (t.match(/\b\d{2,4}\s?(?:m²|m2|sq\.?\s?m|sq\.?\s?ft)/gi) || []).length + (t.match(/\b(king|queen|twin|double)\s+bed/gi) || []).length < 2; };
  let refusesFetch = false;   // M1016: once a site answers a plain request with 403, read it in the browser directly
  const attempt = async (u, fromMenu) => {
    if (!u || tried.has(u)) return null; tried.add(u);
    try {
      let got = null;
      if (refusesFetch) {
        // M1020: on a site that refuses plain requests, a browser read is spent only on an address
        // that looks like a rooms LIST (not a single room's page), and a 404 refunds it.
        const listLike = !/\/(?:guest_rooms|rooms-suites|accommodations?|suites)\/[^/?#]+\/?$/i.test(new URL(u).pathname) || /\/(?:accommodations?|rooms(?:-and-suites|-suites)?|suites|stay|villas)\/?$/i.test(new URL(u).pathname);
        if (!listLike) { TRIED.push({ url: u, skipped: "a single room's page" }); return null; }
        if (browserReads < 3 && Date.now() - T0 < 35000) { browserReads++; got = await getWithBrowser(u); if (!got && TRIED.length && TRIED[TRIED.length - 1].url === u && TRIED[TRIED.length - 1].status === 404) browserReads--; }
        else { TRIED.push({ url: u, skipped: "browser budget spent" }); return null; }
      }
      else { got = await get(u); if (!got && TRIED.length && TRIED[TRIED.length - 1].url === u && TRIED[TRIED.length - 1].status === 403) { refusesFetch = true; if (browserReads < 3) { browserReads++; got = await getWithBrowser(u); } } }
      if (got && looksLikeRooms(got, u)) return got;
      if (got && fromMenu && hollow(got) && !/^browser/.test(got.via || "") && browserReads < 2 && Date.now() - T0 < 30000) {
        browserReads++;
        TRIED.push({ url: u, note: "menu page arrived hollow — opening in the browser" });
        const again = await getWithBrowser(u);
        if (again && looksLikeRooms(again, u)) return again;
        got = again || got;
      }
      TRIED.push({ url: u, verdict: got ? "not a rooms page" : "no page" });
    } catch (e) {}
    return null;
  };
  let home = null;
  try { home = await get(root); } catch (e) { home = null; }
  if (home && /^browser/.test(home.via || "")) refusesFetch = true;
  if (home) {
    const links = []; const re = /<a\b[^>]*href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi; let m;
    while ((m = re.exec(home.html)) && links.length < 600) {
      const u = abs(home.url, m[1]); if (!u || !sameSite(u, home.url)) continue;
      const txt = m[2].replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
      const byText = /^(accommodations?|rooms?(?: (?:&|and) suites)?|suites?(?: (?:&|and) rooms)?|stay|villas?|residences?|tents?|rooms? ?\/ ?suites|guest ?rooms|where to stay|our rooms|the rooms)$/i.test(txt);
      const byUrl = /(^|\/)(accommodations?|rooms?(?:-and-suites|-suites)?|suites?|stay|villas?|tents?|residences?|guest-rooms)(\/|$|\?|#)/i.test(new URL(u).pathname);
      if (byText) { if (/\?/.test(u)) links.push(u); else links.unshift(u); } else if (byUrl) links.push(u);
    }
    // THE HOTEL'S OWN PAGES FIRST (M1015). On a group site the hotel lives at a path
    // (dorchestercollection.com/london/the-dorchester); its own Rooms & Suites page sits under that
    // path, while the group's "Residences" and other hotels' pages do not. Rank own-path links
    // first, and when the hotel has a path of its own, leave the group's pages for last.
    const ownPath = (() => { try { const p = new URL(root).pathname.replace(/\/+$/, "").toLowerCase(); return p && p !== "/" ? p : ""; } catch (e) { return ""; } })();
    const under = (u) => { try { return !!ownPath && new URL(u).pathname.toLowerCase().startsWith(ownPath + "/"); } catch (e) { return false; } };
    let ranked = [...new Set(links)].sort((a, b) => (under(b) ? 1 : 0) - (under(a) ? 1 : 0));
    // THE PARENT IS THE LIST (M1016): a menu that offers classic-room, superior-room, deluxe-room…
    // under /rooms-suites/ is pointing at one list page. Try the parent before its children.
    const parents = {}; for (const u of ranked) { try { const x = new URL(u); const segs = x.pathname.replace(/\/+$/, "").split("/"); if (segs.length > 2) { const p = x.origin + segs.slice(0, -1).join("/"); parents[p] = (parents[p] || 0) + 1; } } catch (e) {} }
    const lists = Object.keys(parents).filter((p) => parents[p] >= 2 && /room|suite|accommodation|stay|villa|residence/i.test(p)).sort((a, b) => parents[b] - parents[a]);
    ranked = [...lists, ...ranked.filter((u) => !lists.includes(u))];
    TRIED.push({ note: "menu candidates", ownPath: ownPath || null, candidates: ranked.slice(0, 8) });
    // M1021: the menu's own LIST page (a parent of several room pages) goes first — the menu knows;
    // guessed addresses are the fallback and stop after two misses. (Hotel Eden: /accommodations/
    // 404 twice, then the clock ran out on /rooms-suites, which was right there at the top.)
    const menuLists = ranked.filter((u) => lists.includes(u));
    for (const u of menuLists.slice(0, 2)) { const got = await attempt(u.split("#")[0], true); if (got) return got; if (Date.now() - T0 > 40000) break; }
    if (refusesFetch) {
      let misses = 0;
      for (const p of ["/accommodations/", "/rooms-suites", "/rooms-and-suites", "/rooms", "/accommodation", "/stay"]) { const before = TRIED.length; const got = await attempt(root + p, false); if (got) return got; if (TRIED.slice(before).some((x) => x.status === 404 || x.verdict === "no page")) misses++; if (misses >= 2 || browserReads >= 3 || Date.now() - T0 > 35000) break; }
    }
    for (const u of ranked.slice(0, 6)) { const got = await attempt(u.split("#")[0], true); if (got) return got; if (Date.now() - T0 > 60000) break; }
  }
  // A GUESSED ADDRESS THAT EXISTS BUT ARRIVES HOLLOW IS OPENED IN THE BROWSER TOO (M1041). Mandarin
  // Oriental's home page draws its menu with JavaScript, so no menu link was found; the guess
  // /stay — the right page — answered 200 as an empty shell and was judged "not a rooms page" on
  // that shell. A real page (200) that is hollow now gets the same browser look a menu page gets,
  // within the same browser budget. Addresses that do not exist (404) still cost nothing.
  for (const p of ROOM_PATHS) {
    for (const cand of [root + p, origin + p]) { const got = await attempt(cand, true); if (got) return got; }
  }
  return home;   // better than nothing: the reader may still find a rooms section, or say no-rooms-found
}

// A HARD 50-SECOND ANSWER (M1014): Safari drops the request at ~60 s and shows "server stopped
// responding". Whatever is known by 50 s is sent back with the list of addresses tried.
// FINISH IN THE BACKGROUND (M1022). A big site read cold (three browser round-trips and a 700 KB
// page through the model — Four Seasons New York) takes longer than Safari will wait. At 45 s the
// reader answers "still reading" and KEEPS GOING: the function stays alive until the read is done
// (Vercel's waitUntil; the rooms function has 90 s), the result lands in the store, and the card,
// which polls every few seconds on "reading", picks it up. The client never sees a timeout.
import { waitUntil } from "@vercel/functions";
export default async function handler(req, res) {
  let sent = false; const json = res.json.bind(res); res.json = (b) => { if (sent) return res; sent = true; return json(b); };
  // FINISHING IN THE BACKGROUND MUST NOT TOUCH THE ANSWER ALREADY SENT (M1041, 2 Nov 2026). After the
  // 45-second "still reading" answer, the background read went on to set a header for its own answer —
  // and Node refuses headers once an answer has gone ("Cannot set headers after they are sent"). That
  // error was recorded as the read's failure and the rooms were never stored, so EVERY hotel whose
  // read took longer than 45 seconds failed, however well the read itself went (Mandarin Oriental
  // Ritz Madrid, 2 Nov). Once an answer is sent, headers and status are left alone.
  const setHeader = res.setHeader.bind(res); res.setHeader = (k, v) => { if (sent || res.headersSent) return res; return setHeader(k, v); };
  const status = res.status.bind(res); res.status = (c) => { if (sent || res.headersSent) return res; return status(c); };
  const timer = new Promise((r) => setTimeout(r, 45000, "timeout"));
  let outcome = "done";
  STORE_LOG.length = 0;
  const site = String((req.query || {}).site || "").slice(0, 300).trim();
  const job = work(req, res).then(() => "done").catch(async (e) => { const msg = "error:" + String(e && e.message || e).slice(0, 300); try { await noteFailure(site, msg); } catch (x) {} return msg; });
  try { outcome = await Promise.race([job, timer]); } catch (e) { outcome = "error:" + String(e && e.message || e).slice(0, 200); }
  if (outcome !== "timeout") await closeSession();
  if (!sent) {
    res.setHeader("Cache-Control", "no-store");
    if (outcome === "timeout") { try { waitUntil(job); } catch (e) {} res.status(200).json({ ok: false, reason: "reading", detail: "still reading the hotel's site — ask again in a few seconds", store: STORE_LOG.slice(-6), tried: TRIED.slice(-40) }); }
    else res.status(200).json({ ok: false, reason: "error", detail: outcome, tried: TRIED.slice(-40) });
  }
}
// THE ROOMS STORE (M1019). Vercel's cache is wiped by every deploy, so the first open of every
// hotel after a deploy paid the full 35–60 s read. The rooms now also live in Supabase
// (table hotel_rooms, 30-day freshness), written by the server with the service key and read
// before any site is touched. Env in Vercel: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY. Without
// them the store is simply skipped.
// ONE KEY PER HOTEL (M1027). Google hands the card a tracking-tagged address
// (https://www.fourseasons.com/newyork/?utm_source=google…) while the tests used the bare one;
// two keys, two store entries, and the card kept serving the older. The store key is the address
// with scheme, www., tracking parameters, fragments and trailing slashes removed, lower-cased.
function siteKey(site) {
  let s = String(site || "").trim();
  try {
    const u = new URL(/^https?:\/\//.test(s) ? s : "https://" + s);
    const keep = [...u.searchParams.entries()].filter(([k]) => !/^(utm_|gclid|fbclid|mc_|ref$|source$|campaign|medium|cid$|icid|sc_)/i.test(k));
    const q = keep.length ? "?" + keep.map(([k, v]) => `${k}=${v}`).join("&") : "";
    return (u.hostname.replace(/^www\./i, "") + u.pathname.replace(/\/+$/, "") + q).toLowerCase();
  } catch (e) { return s.replace(/^https?:\/\//i, "").replace(/^www\./i, "").replace(/[?#].*$/, "").replace(/\/+$/, "").toLowerCase(); }
}
const STORE_URL = (process.env.SUPABASE_URL || "").trim().replace(/\/+$/, "");
const STORE_KEY = (process.env.SUPABASE_SERVICE_ROLE_KEY || "").trim();
const FRESH_MS = 30 * 86400000;
const STORE_TRUST_FROM = "2026-10-27T22:00:00Z";   // entries older than this were written by readers before M1020–M1025; step this forward whenever the reader's results change
async function storeRead(site) {
  if (!STORE_URL || !STORE_KEY) return null;
  try {
    const r = await fetch(`${STORE_URL}/rest/v1/hotel_rooms?site=eq.${encodeURIComponent(siteKey(site))}&select=hotel,source,booking,rooms,fetched_at`, { headers: { apikey: STORE_KEY, Authorization: `Bearer ${STORE_KEY}` } });
    STORE_LOG.push({ store: "read", status: r.status, body: r.ok ? undefined : (await r.text()).slice(0, 200) });
    if (!r.ok) return null;
    const rows = await r.json(); const row = rows && rows[0];
    if (!row || !Array.isArray(row.rooms) || !row.rooms.length) return null;
    if (row.source === "reading") return (Date.now() - Date.parse(row.fetched_at) < 120000) ? { reading: true } : null;   // M1023: a read in progress elsewhere
    if (row.source === "failed") return { failed: row.rooms && row.rooms[0] ? row.rooms[0] : { failed: "unknown" }, at: row.fetched_at };   // M1024: what went wrong last time
    if (Date.now() - Date.parse(row.fetched_at) > FRESH_MS) return null;
    if (Date.parse(row.fetched_at) < Date.parse(STORE_TRUST_FROM)) return null;   // M1027: written by an older reader — read afresh
    // NO PHOTOGRAPHS, READ BEFORE THE PHOTO FIX (3 Nov 2026). Until M1043 (2 Nov, 20:27 ET) pictures that
    // load as you scroll came back as placeholders, so Mandarin Oriental's rooms were saved with no
    // photographs at all. A saved list from before then with not one photograph is read again, once;
    // lists read after the fix are trusted as they are. Universal — every hotel.
    if (Date.parse(row.fetched_at) < Date.parse("2026-11-03T01:30:00Z") && !row.rooms.some((x) => x && Array.isArray(x.images) && x.images.length)) return null;
    // PHOTOGRAPHS WRONGLY CLEARED (3 Nov 2026): a room checked against a page it shared with other
    // rooms, or against the list page itself, lost its photographs. Such a list is read afresh, once.
    { const own = ownPages(row.rooms, row.source); if (row.rooms.some((x) => x && x.photoChecked && !own(x))) return null; }
    return row;
  } catch (e) { return null; }
}
const READING = {};   // site → started-at (this instance); the store carries a marker for other instances
const STORE_LOG = [];
async function markReading(site, hotel) {
  READING[site] = Date.now();
  if (!STORE_URL || !STORE_KEY) { STORE_LOG.push({ store: "off", url: !!STORE_URL, key: !!STORE_KEY }); return; }
  try { const r = await fetch(`${STORE_URL}/rest/v1/hotel_rooms?on_conflict=site`, { method: "POST", headers: { apikey: STORE_KEY, Authorization: `Bearer ${STORE_KEY}`, "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify({ site: siteKey(site), hotel, source: "reading", booking: null, rooms: [{ reading: true }], fetched_at: new Date().toISOString() }) }); STORE_LOG.push({ store: "mark", status: r.status, body: r.ok ? undefined : (await r.text()).slice(0, 200) }); } catch (e) { STORE_LOG.push({ store: "mark", error: String(e && e.message || e).slice(0, 120) }); }
}
async function noteFailure(site, msg) {
  if (!STORE_URL || !STORE_KEY || !site) return;
  try { await fetch(`${STORE_URL}/rest/v1/hotel_rooms?on_conflict=site`, { method: "POST", headers: { apikey: STORE_KEY, Authorization: `Bearer ${STORE_KEY}`, "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify({ site: siteKey(site), hotel: "", source: "failed", booking: null, rooms: [{ failed: msg, log: STORE_LOG.slice(-6), tried: TRIED.slice(-12) }], fetched_at: new Date().toISOString() }) }); } catch (e) {}
}
async function clearReading(site) {
  delete READING[site];
  if (!STORE_URL || !STORE_KEY) return;
  try { await fetch(`${STORE_URL}/rest/v1/hotel_rooms?site=eq.${encodeURIComponent(siteKey(site))}&source=in.(reading,failed)`, { method: "DELETE", headers: { apikey: STORE_KEY, Authorization: `Bearer ${STORE_KEY}` } }); } catch (e) {}
}
async function storeWrite(site, hotel, source, booking, rooms) {
  if (!STORE_URL || !STORE_KEY) return false;
  try {
    const r = await fetch(`${STORE_URL}/rest/v1/hotel_rooms?on_conflict=site`, { method: "POST", headers: { apikey: STORE_KEY, Authorization: `Bearer ${STORE_KEY}`, "Content-Type": "application/json", Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify({ site: siteKey(site), hotel, source, booking, rooms, fetched_at: new Date().toISOString() }) });
    STORE_LOG.push({ store: "write", status: r.status, body: r.ok ? undefined : (await r.text()).slice(0, 200) });
    return r.ok;
  } catch (e) { STORE_LOG.push({ store: "write", error: String(e && e.message || e).slice(0, 120) }); return false; }
}
async function work(req, res) {
  const T0 = Date.now();
  res.setHeader("Access-Control-Allow-Origin", "*");
  const key = process.env.ANTHROPIC_API_KEY;
  res.setHeader("Cache-Control", "no-store");
  if (!key) return res.status(200).json({ ok: false, reason: "no-key" });
  TRIED.length = 0;
  const debug = String(req.query.debug || "") === "1";
  const hotel = String(req.query.hotel || "").slice(0, 120).trim();
  const site = String(req.query.site || "").slice(0, 300).trim();
  if (!hotel || !site || !/^[a-z0-9.-]+\.[a-z]{2,}/i.test(site.replace(/^https?:\/\//, ""))) return res.status(200).json({ ok: false, reason: "bad-request" });

  // The store first: no site is touched for a hotel read within the month.
  if (String(req.query.fresh || "") !== "1") {
    const kept = await storeRead(site);
    if (kept && kept.failed) { await clearReading(site); if (debug) { res.setHeader("Cache-Control", "no-store"); return res.status(200).json({ ok: false, reason: "last-read-failed", at: kept.at, failed: kept.failed, note: "the note is cleared; this request is reading afresh — run again" }); } }
    if (kept && kept.reading) { res.setHeader("Cache-Control", "no-store"); return res.status(200).json({ ok: false, reason: "reading", detail: "still reading the hotel's site — ask again in a few seconds", via: "store" }); }
    if (kept) {
      let rooms = Array.isArray(kept.rooms) ? kept.rooms.map(unGarbleRoom) : kept.rooms;
      let via = "store";
      const own = ownPages(rooms || [], kept.source);
      if (Array.isArray(rooms) && rooms.some((x) => x && own(x) && x.photoChecked !== PHOTO_PASS && !(x.photoTried > Date.now() - 864e5))) {
        rooms = await roomPagePhotos(rooms, 30000, kept.source);
        await closeSession();
        await storeWrite(site, kept.hotel || hotel, kept.source, kept.booking || null, rooms);
        via = "store+room-pages";
      }
      res.setHeader("Cache-Control", "public, s-maxage=2592000, stale-while-revalidate=604800");
      return res.status(200).json({ ok: true, hotel: kept.hotel || hotel, source: kept.source, booking: kept.booking || null, fetched: kept.fetched_at, rooms, via, tried: debug ? TRIED : undefined });
    }
  }
  await markReading(site, hotel);
  let page = null;
  try { page = await findRoomsPage(site); } catch (e) { page = null; }
  // A HOLLOW PAGE IS READ AGAIN IN THE BROWSER (M997). Rosewood's accommodation page arrives as a
  // shell — menu and a promo — and draws its rooms with JavaScript afterwards; a plain fetch
  // never sees them. If the page we hold shows few room signals, open it in the browser.
  const roomSignals = (html) => { const t = String(html || "").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " "); return (t.match(/\b\d{2,4}\s?(?:m²|m2|sq\.?\s?m|sq\.?\s?ft)/gi) || []).length + (t.match(/\b(king|queen|twin|double)\s+bed/gi) || []).length; };
  if (page && !/^browser/.test(page.via || "") && roomSignals(page.html) < 2) {
    TRIED.push({ url: page.url, note: "hollow — reading again in the browser", signals: roomSignals(page.html) });
    try { const again = await getWithBrowser(page.url); if (again && roomSignals(again.html) > roomSignals(page.html)) page = again; } catch (e) {}
  }
  if (!page) { await clearReading(site); res.setHeader("Cache-Control", "no-store"); return res.status(200).json({ ok: false, reason: "unreachable", hotel, site, node: process.version, hostedBrowser: !!(process.env.BROWSERLESS_TOKEN || "").trim(), tokenLength: (process.env.BROWSERLESS_TOKEN || "").trim().length, tried: TRIED }); }
  await closeSession();   // M1025: the browser is not needed past this point
  // The hotel's own "Check Rates" link, from the page we already hold, so the rates reader need
  // not open the site again to find it (M985). Prefer the link that names the hotel.
  const booking = (() => {
    const ENG = /reservations\.fourseasons\.com|be\.synxis\.com|reservations\.travelclick\.com|ihotelier|secure-hotel-booking|reservation\.|reservations\.|\/reservations\/|\/booking\/|\/book\/|hilton\.com\/[a-z]{2}\/book|ctyhocn=|hyatt\.com\/shop\/rooms|all\.accor\.com\/(?:ssr|hotel|lien_externe)|marriott\.com\/reservation|propertyCode=|[?&]chain=\d+/i;   // own /reservations/ (M1002); Hilton, Hyatt, Accor, Marriott (M1011); SynXis by signature (M1018)
    const CODED = /(?:locationId|hotelCode|hotel|hotelId|propertyId|productId|chain|Hotel|Chain)=/;
    const urls = []; const re = /href\s*=\s*["']([^"']+)["']/gi; let m;
    while ((m = re.exec(page.html))) { try { urls.push(new URL(m[1].replace(/&amp;/g, "&"), page.url).toString()); } catch (e) {} }
    const eng = urls.filter((u) => ENG.test(u) && !/\/(?:profile|signin|sign-in|login|findreservation|find-reservation|itinerary|modify|cancel)/i.test(u));
    return eng.find((u) => CODED.test(u)) || eng[0] || null;
  })();
  // THE ROOMS ARE A FRACTION OF THE PAGE (M1023). Four Seasons New York's accommodations page is
  // 685 KB; the room list is a few thousand words of it. Keep the stretch of text where room
  // signals (sizes, beds, "suite", "room") are densest, up to 45,000 characters, so the model
  // answers in time and the first read fits inside one call.
  const whole = distill(page.html, page.url);
  const text = (() => {
    if (whole.length <= 45000) return whole;
    const W = 3000; const n = Math.ceil(whole.length / W); const score = [];
    for (let i = 0; i < n; i++) { const seg = whole.slice(i * W, (i + 1) * W); score.push((seg.match(/\b\d{2,4}\s?(?:m²|m2|sq\.?\s?m|sq\.?\s?ft)/gi) || []).length * 3 + (seg.match(/\b(king|queen|twin|double)\s+bed/gi) || []).length * 2 + (seg.match(/\b(suite|room|penthouse|villa)\b/gi) || []).length + (seg.match(/\[IMG#/g) || []).length); }
    const span = Math.floor(45000 / W); let best = 0, bestSum = -1;
    for (let i = 0; i + span <= n; i++) { const s = score.slice(i, i + span).reduce((a, b) => a + b, 0); if (s > bestSum) { bestSum = s; best = i; } }
    return whole.slice(best * W, best * W + 45000);
  })();
  if (text.length < 300) { await clearReading(site); return res.status(200).json({ ok: false, reason: "empty", hotel, source: page.url, tried: debug ? TRIED : undefined }); }

  const prompt = `Below is the text of a hotel's own website page, with its images shown as [IMG#n | alt] (n is the image number) and links as [LINK url]. The hotel is "${hotel}". Extract the hotel's ROOM AND SUITE CATEGORIES exactly as the hotel names them.

Return ONLY a JSON object: { "rooms": [ { "name", "category", "size", "beds", "occupancy", "view", "description", "images", "url" } ] }
- name: the room/suite/villa name exactly as written on the page
- category: the section heading it sits under on the page (e.g. "Guest Rooms", "Suites", "Specialty Suites"), or null
- size: the size text as written (e.g. "45–50 m2 (484–538 sq. ft.)"), or null
- beds: bed configuration as written, or null
- occupancy: as written, or null
- view: the view or defining feature as written (terrace, balcony, garden, sea view), or null
- description: the hotel's own one- or two-sentence description of that room if present, else null — never write your own
- images: up to 2 image NUMBERS (plain integers) that belong to this room (the [IMG#n] entries nearest its name, or whose alt names it); [] if none
- url: the room's own detail page [LINK] if there is one, else null
Rules: list every category once, in page order; do not invent, merge or rename rooms; skip offers, dining, spa and navigation; if the page has no rooms, return { "rooms": [] }. No prose outside the JSON.

PAGE TEXT
${text}`;

  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: MODEL, max_tokens: 8000, messages: [{ role: "user", content: prompt }] }),
    });
    if (!r.ok) { const detail = await r.text(); await noteFailure(site, `anthropic ${r.status}: ${detail.slice(0, 200)}`); return res.status(200).json({ ok: false, reason: "anthropic-error", status: r.status, detail: detail.slice(0, 200) }); }
    const data = await r.json();
    const out = (data.content || []).map((b) => b.text || "").join("").trim();
    const jm = /\{[\s\S]*\}/.exec(out);
    let parsed; try { parsed = jm ? JSON.parse(jm[0]) : null; } catch (e) { parsed = null; }
    if (!parsed || !Array.isArray(parsed.rooms)) {
      // A long answer can be cut off mid-list: keep every room object that is complete.
      const objs = []; const re = /\{\s*"name"\s*:[\s\S]*?\}(?=\s*(?:,\s*\{|\s*\]))/g; let m;
      while ((m = re.exec(out))) { try { objs.push(JSON.parse(m[0])); } catch (e) {} }
      parsed = objs.length ? { rooms: objs, truncated: true } : null;
    }
    if (!parsed || !Array.isArray(parsed.rooms)) return res.status(200).json({ ok: false, reason: "unreadable", hotel, source: page.url, textLength: text.length, tried: debug ? TRIED : undefined, answer: debug ? out.slice(0, 1500) : undefined, sample: debug ? text.slice(0, 2000) : undefined });
    const S = (v, n = 300) => (v == null || v === "" ? null : unGarble(String(v)).trim().slice(0, n));
    const rooms = parsed.rooms.filter((x) => x && x.name).slice(0, 40).map((x) => ({
      name: S(x.name, 120), category: S(x.category, 80), size: S(x.size, 80), beds: S(x.beds, 120), occupancy: S(x.occupancy, 120), view: S(x.view, 120), description: S(x.description, 600),
      images: (Array.isArray(x.images) ? x.images : []).map(cleanUrl).map((v) => { const n = parseInt(String(v).replace(/[^0-9]/g, ""), 10); return n >= 1 && n <= IMAGES.length ? IMAGES[n - 1] : (typeof v === "string" && /^https?:\/\//.test(v) ? v : null); }).filter(Boolean).slice(0, 2),
      url: typeof x.url === "string" && /^https?:\/\//.test(x.url) ? x.url : null,
    }));
    res.setHeader("Cache-Control", "public, s-maxage=2592000, stale-while-revalidate=604800");
    if (!rooms.length) { await clearReading(site); res.setHeader("Cache-Control", "no-store"); return res.status(200).json({ ok: false, reason: "no-rooms-found", hotel, source: page.url, tried: debug ? TRIED : undefined, sample: debug ? text.slice(0, 2000) : undefined }); }
    // THE READ IS KEPT FIRST (3 Nov 2026). A long read (Belmond, through the browser) plus the room
    // pages ran past the function's 90 seconds and was cut off before anything was saved — so the
    // card asked forever and was told "still reading". The rooms are saved the moment they are read;
    // the photo pass then uses only the time left, and saves again if it changed anything.
    let stored = await storeWrite(site, hotel, page.url, booking, rooms);
    const left = 80000 - (Date.now() - T0);
    if (left > 8000) {
      const checked = await roomPagePhotos(rooms, Math.min(25000, left - 5000), page.url);
      await closeSession();
      rooms.splice(0, rooms.length, ...checked);
      stored = (await storeWrite(site, hotel, page.url, booking, rooms)) || stored;
    }
    return res.status(200).json({ ok: true, hotel, source: page.url, booking, stored, fetched: new Date().toISOString(), rooms, truncated: parsed.truncated ? true : undefined, tried: debug ? TRIED : undefined });
  } catch (e) {
    await noteFailure(site, "model:" + String(e && e.message || e).slice(0, 300));
    return res.status(200).json({ ok: false, reason: "fetch", detail: String(e && e.message || e).slice(0, 200) });
  }
}
